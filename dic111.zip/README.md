
Dic - ATOM

Dic is a POW\PoS -based cryptocurrency.

Development process
===========================

SPECIFICATIONS



Scrypt
PoW/PoS

Time blocks: 60 sec.
Block reward: 600
POW: 20 000 blocks
Total coins: 12,000,000
PoS: Yearly Interest 100%
Min.Coin age: 8 hours
Max age: unlimited
RPC 8568 
P2P 8567

Block Explorer:
https://chainz.cryptoid.info/atx/

Bitcointalk thred:
https://bitcointalk.org/index.php?topic=1625302.0

Website:
http://dic-coin.com/

